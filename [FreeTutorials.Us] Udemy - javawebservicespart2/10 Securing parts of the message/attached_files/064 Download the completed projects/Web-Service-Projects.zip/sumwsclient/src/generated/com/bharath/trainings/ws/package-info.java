@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.trainings.bharath.com/")
package com.bharath.trainings.ws;
